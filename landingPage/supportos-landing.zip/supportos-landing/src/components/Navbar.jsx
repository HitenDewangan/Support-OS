import React from 'react'
import './Navbar.css'

export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="nav-logo">
        <div className="logo-icon">🛟</div>
        SupportOS
      </div>

      <ul className="nav-links">
        <li><a href="#platform">Platform</a></li>
        <li><a href="#roles">Roles</a></li>
        <li><a href="#features">Features</a></li>
        <li><a href="#roadmap">Roadmap</a></li>
      </ul>

      <div className="nav-right">
        <a className="btn-ghost" href="#">Sign In</a>
        <a className="btn-nav" href="#">Request Demo</a>
      </div>
    </nav>
  )
}
